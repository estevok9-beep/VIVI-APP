import "./registerPWA.js";



import React, {

  useCallback,

  useEffect,

  useState

} from "react";

import ReactDOM from "react-dom/client";

import App from "./App.jsx";

import AuthForm from "./auth/AuthForm.jsx";

import AdminPanel from "./Admin/AdminPanel.jsx";
import Configuracoes from "./configuracoes/Configuracoes.jsx";
import Assinaturas from "./assinaturas/Assinaturas.jsx";

import { supabase } from "./supabase.js";

import "./index.css";
import "./VivSidebar.css";

// ==========================================

// TELA DE ATIVAÇÃO DE CONVITES

// ==========================================

function TelaConvite({

  acesso,

  atualizarAcesso,

  sair

}) {

  const [codigo, setCodigo] = useState("");

  const [ativando, setAtivando] = useState(false);

  const [erro, setErro] = useState("");

  const possuiConviteAnterior =

    Boolean(acesso?.expira_em);

  async function ativarConvite(evento) {

    evento.preventDefault();

    if (ativando || !codigo.trim()) {

      return;

    }

    setAtivando(true);

    setErro("");

    try {

      const { error } = await supabase.rpc(

        "vivi_ativar_convite",

        {

          p_codigo: codigo

            .trim()

            .toUpperCase()

        }

      );

      if (error) {

        throw error;

      }

      await atualizarAcesso();

    } catch (error) {

      setErro(

        "Não foi possível ativar o convite: " +

          error.message

      );

    } finally {

      setAtivando(false);

    }

  }

  return (

    <main

      style={{

        minHeight: "100vh",

        display: "grid",

        placeItems: "center",

        padding: 20,

        background: "#081b2d",

        color: "#ffffff"

      }}

    >

      <section

        style={{

          width: "100%",

          maxWidth: 480,

          padding: 32,

          borderRadius: 20,

          border: "1px solid #28546a",

          background: "#102339",

          boxShadow: "0 20px 60px #0005"

        }}

      >

        <h1

          style={{

            marginBottom: 5,

            color: "#00e59a",

            fontSize: 38

          }}

        >

          Viv

        </h1>

        <p

          style={{

            color: "#9eb6c8",

            marginTop: 0

          }}

        >

          CONTROLE FINANCEIRO

        </p>

        <div

          style={{

            height: 3,

            width: 65,

            background: "#00e59a",

            margin: "25px 0"

          }}

        />

        <h2>

          {possuiConviteAnterior

            ? "Seu acesso está encerrado"

            : "Ative seu convite"}

        </h2>

        <p

          style={{

            color: "#b4cada",

            lineHeight: 1.7

          }}

        >

          {possuiConviteAnterior

            ? "O prazo do seu convite terminou ou ele foi revogado. Entre em contato com o administrador da Viv."

            : "Informe o código recebido para ativar seu período de acesso à plataforma."}

        </p>

        {possuiConviteAnterior &&

          acesso?.expira_em && (

            <div

              style={{

                margin: "20px 0",

                padding: 15,

                borderRadius: 10,

                background: "#4a2939",

                color: "#ffb3c4"

              }}

            >

              Vencimento:{" "}

              {new Date(

                acesso.expira_em

              ).toLocaleString("pt-BR")}

            </div>

          )}

        {!possuiConviteAnterior && (

          <form

            onSubmit={ativarConvite}

            style={{

              display: "grid",

              gap: 15,

              marginTop: 25

            }}

          >

            <label

              htmlFor="codigo-convite"

              style={{

                fontWeight: 700

              }}

            >

              Código do convite

            </label>

            <input

              id="codigo-convite"

              type="text"

              value={codigo}

              onChange={(evento) => {

                setCodigo(

                  evento.target.value

                    .toUpperCase()

                );

              }}

              placeholder="Digite seu código"

              autoComplete="off"

              required

              style={{

                width: "100%",

                boxSizing: "border-box",

                padding: 15,

                borderRadius: 10,

                border:

                  "1px solid #36839b",

                background: "#071929",

                color: "#ffffff",

                fontSize: 16,

                letterSpacing: 1

              }}

            />

            {erro && (

              <p

                role="alert"

                style={{

                  padding: 12,

                  borderRadius: 8,

                  background: "#57283a",

                  color: "#ffb1c2"

                }}

              >

                {erro}

              </p>

            )}

            <button

              type="submit"

              disabled={ativando}

              style={{

                padding: 15,

                border: "none",

                borderRadius: 10,

                background: "#00bb88",

                color: "#05251b",

                fontWeight: 800,

                cursor: ativando

                  ? "wait"

                  : "pointer",

                opacity: ativando

                  ? 0.6

                  : 1

              }}

            >

              {ativando

                ? "Ativando convite..."

                : "Ativar convite"}

            </button>

          </form>

        )}

        <button

          type="button"

          onClick={sair}

          style={{

            display: "block",

            marginTop: 25,

            padding: "12px 18px",

            border:

              "1px solid #456780",

            borderRadius: 9,

            background: "transparent",

            color: "#ffffff",

            cursor: "pointer"

          }}

        >

          Sair da conta

        </button>

      </section>

    </main>

  );

}

// ==========================================

// APLICATIVO PRINCIPAL

// ==========================================

function MenuIcon({ name }) {
  const paths = {
    menu: <><path d="M4 7h16M4 12h16M4 17h16" /></>,
    dashboard: <><rect x="3" y="3" width="7" height="7" rx="1" /><rect x="14" y="3" width="7" height="7" rx="1" /><rect x="3" y="14" width="7" height="7" rx="1" /><rect x="14" y="14" width="7" height="7" rx="1" /></>,
    admin: <><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10Z" /><path d="m9 12 2 2 4-4" /></>,
    settings: <><path d="M12 8a4 4 0 1 0 0 8 4 4 0 0 0 0-8Z" /><path d="M19.4 15a1.7 1.7 0 0 0 .34 1.88l.06.06-2 2-.06-.06a1.7 1.7 0 0 0-1.88-.34 1.7 1.7 0 0 0-1.05 1.56V21h-2.82v-.1a1.7 1.7 0 0 0-1.05-1.56 1.7 1.7 0 0 0-1.88.34l-.06.06-2-2 .06-.06A1.7 1.7 0 0 0 7.4 15a1.7 1.7 0 0 0-1.56-1.05H5v-2.82h.84A1.7 1.7 0 0 0 7.4 10a1.7 1.7 0 0 0-.34-1.88L7 8.06l2-2 .06.06A1.7 1.7 0 0 0 11 6.46a1.7 1.7 0 0 0 1.05-1.56V4h2.82v.9A1.7 1.7 0 0 0 15.92 6a1.7 1.7 0 0 0 1.88-.34l.06-.06 2 2-.06.06A1.7 1.7 0 0 0 19.46 10a1.7 1.7 0 0 0 1.56 1.05H22v2.82h-.98A1.7 1.7 0 0 0 19.4 15Z" transform="translate(-.5 -.5)" /></>,
    nova: <><path d="M12 5v14M5 12h14" /><circle cx="12" cy="12" r="9" /></>,
    historico: <><path d="M4 7h16M4 12h16M4 17h16" /><circle cx="6" cy="7" r="1" /></>,
    categorias: <><path d="m3 12 9-9h8v8l-9 9-8-8Z" /><circle cx="16" cy="8" r="1" /></>,
    metas: <><circle cx="12" cy="12" r="9" /><circle cx="12" cy="12" r="5" /><circle cx="12" cy="12" r="1" /></>,
    relatorios: <><path d="M4 20V10M10 20V4M16 20v-8M22 20V7" /></>,
    logout: <><path d="M10 17l5-5-5-5M15 12H3" /><path d="M12 3h6a3 3 0 0 1 3 3v12a3 3 0 0 1-3 3h-6" /></>
  };
  return <svg className="viv-nav-icon" width="21" height="21" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">{paths[name]}</svg>;
}

function Viv() {

  const [menuExpandido, setMenuExpandido] = useState(() => window.innerWidth > 700);
  const [paginaFinanceira, setPaginaFinanceira] = useState("inicio");
  const [usuario, setUsuario] =

    useState(null);

  const [

    administrador,

    setAdministrador

  ] = useState(false);

  const [

    autorizado,

    setAutorizado

  ] = useState(false);

  const [acesso, setAcesso] =

    useState(null);

  const [bloqueado, setBloqueado] = useState(false);

  const [tela, setTela] =

    useState("financeiro");

  const [

    carregando,

    setCarregando

  ] = useState(true);

  const [

    verificando,

    setVerificando

  ] = useState(false);

  const [

    erroAcesso,

    setErroAcesso

  ] = useState("");

  // ========================================

  // CONSULTAR PERMISSÃO NO SUPABASE

  // ========================================

  const verificarAcesso = useCallback(

    async () => {

      setVerificando(true);

      try {

        const { data, error } =

          await supabase.rpc(

            "vivi_meu_acesso"

          );

        if (error) {

          throw error;

        }

        const resultado =

          data?.[0] || null;

        if (!resultado) {

          throw new Error(

            "O servidor não retornou informações de acesso."

          );

        }

        const admin =

          resultado.administrador === true;

        // O RPC antigo pode não conhecer o bloqueio novo.

        // A função de segurança do banco é a autoridade final.

        const { data: acessoValido, error: erroValidade } =

          await supabase.rpc("vivi_acesso_valido");

        if (erroValidade) throw erroValidade;

        const { data: estaBloqueado, error: erroBloqueio } =

          await supabase.rpc("vivi_meu_bloqueio");

        if (erroBloqueio) throw erroBloqueio;

        const permitido = resultado.autorizado === true && acessoValido === true && estaBloqueado !== true;

        setBloqueado(estaBloqueado === true);

        setAcesso(resultado);

        setAdministrador(admin);

        setAutorizado(permitido);

        setErroAcesso("");

        if (!admin) {

          setTela("financeiro");

        }

        return permitido;

      } catch (error) {

        setAdministrador(false);

        setAutorizado(false);

        setBloqueado(false);

        setErroAcesso(

          "Erro ao verificar acesso: " +

            error.message

        );

        return false;

      } finally {

        setVerificando(false);

      }

    },

    []

  );

  // ========================================

  // AUTENTICAÇÃO

  // ========================================

  useEffect(() => {

    let ativo = true;

    let sequencia = 0;

    async function verificarSessao() {

      const chamada = ++sequencia;

      setCarregando(true);

      try {

        const { data, error } =

          await supabase.auth.getUser();

        if (

          !ativo ||

          chamada !== sequencia

        ) {

          return;

        }

        if (error || !data.user) {

          setUsuario(null);

          setAdministrador(false);

          setAutorizado(false);

          setBloqueado(false);

          setAcesso(null);

          setErroAcesso("");

          setTela("financeiro");

          return;

        }

        setUsuario(data.user);

        await verificarAcesso();

      } catch (error) {

        if (ativo) {

          setErroAcesso(

            "Erro de autenticação: " +

              error.message

          );

          setAutorizado(false);

        }

      } finally {

        if (

          ativo &&

          chamada === sequencia

        ) {

          setCarregando(false);

        }

      }

    }

    verificarSessao();

    const { data: listener } =

      supabase.auth.onAuthStateChange(

        () => {

          // Evita executar chamadas do Supabase

          // diretamente dentro do callback.

          setTimeout(() => {

            if (ativo) {

              verificarSessao();

            }

          }, 0);

        }

      );

    // Revalidação periódica do convite.

    const intervalo = setInterval(

      () => {

        verificarAcesso();

      },

      60000

    );

    // Revalidar quando o usuário

    // retornar à aba do aplicativo.

    function verificarAoRetornar() {

      if (

        document.visibilityState ===

        "visible"

      ) {

        verificarAcesso();

      }

    }

    document.addEventListener(

      "visibilitychange",

      verificarAoRetornar

    );

    return () => {

      ativo = false;

      sequencia++;

      clearInterval(intervalo);

      document.removeEventListener(

        "visibilitychange",

        verificarAoRetornar

      );

      listener.subscription.unsubscribe();

    };

  }, [verificarAcesso]);

  // ========================================

  // SAIR DA CONTA

  // ========================================

  async function sair() {

    const { error } =

      await supabase.auth.signOut();

    if (error) {

      alert(

        "Erro ao sair: " +

          error.message

      );

    }

  }

  // ========================================

  // TELAS DE CARREGAMENTO

  // ========================================

  if (carregando) {

    return (

      <main

        style={{

          minHeight: "100vh",

          display: "grid",

          placeItems: "center",

          background: "#081b2d",

          color: "#00e59a",

          fontSize: 22,

          fontWeight: 700

        }}

      >

        Carregando Viv...

      </main>

    );

  }

    // ========================================

    // LOGIN — Viv 2.5 NEON GLASS

    // ========================================

    if (!usuario) {

    return <AuthForm />;
  }





  // ========================================

  // ERRO NA CONSULTA DE ACESSO

  // ========================================

  if (erroAcesso) {

    return (

      <main

        style={{

          minHeight: "100vh",

          display: "grid",

          placeItems: "center",

          padding: 20,

          background: "#081b2d",

          color: "#ffffff"

        }}

      >

        <section

          style={{

            maxWidth: 460,

            padding: 30,

            borderRadius: 16,

            background: "#102339"

          }}

        >

          <h2>

            Não foi possível verificar

            seu acesso.

          </h2>

          <p

            style={{

              lineHeight: 1.6

            }}

          >

            {erroAcesso}

          </p>

          <button

            type="button"

            onClick={verificarAcesso}

            disabled={verificando}

          >

            {verificando

              ? "Verificando..."

              : "Tentar novamente"}

          </button>

          <button

            type="button"

            onClick={sair}

            style={{

              marginLeft: 10

            }}

          >

            Sair da conta

          </button>

        </section>

      </main>

    );

  }

  // ========================================

  // CONVITE OBRIGATÓRIO

  // ========================================

  if (bloqueado) {

    return (

      <main style={{minHeight:"100vh",display:"grid",placeItems:"center",background:"#081b2d",color:"white",padding:20}}>

        <section style={{maxWidth:480,background:"#102339",padding:30,borderRadius:16}}>

          <h1 style={{color:"#ff8496"}}>Acesso temporariamente bloqueado</h1>

          <p>Entre em contato com o administrador da Viv. Seus dados financeiros foram preservados.</p>

          <button type="button" onClick={verificarAcesso} disabled={verificando}>Verificar novamente</button>{" "}

          <button type="button" onClick={sair}>Sair da conta</button>

        </section>

      </main>

    );

  }



  if (!autorizado) {

    return (

      <TelaConvite

        acesso={acesso}

        atualizarAcesso={

          verificarAcesso

        }

        sair={sair}

      />

    );

  }

  // ========================================

  // APLICATIVO LIBERADO

  // ========================================

  return (
    <div className="viv-shell">
      <aside className={`viv-sidebar ${menuExpandido ? "viv-sidebar--expanded" : ""}`} aria-label="Menu principal">
        <div className="viv-sidebar-brand">
          <span className="viv-brand-mark">V</span>
          <span className="viv-sidebar-label viv-brand-name">Viv</span>
          <button type="button" className="viv-menu-toggle" aria-label={menuExpandido ? "Recolher menu" : "Expandir menu"} aria-expanded={menuExpandido} onClick={() => setMenuExpandido(!menuExpandido)}>
            <MenuIcon name="menu" />
          </button>
        </div>
        <nav className="viv-sidebar-nav" aria-label="Navegação">
          {[
            ["inicio", "dashboard", "Painel financeiro"],
            ["nova", "nova", "Nova transação"],
            ["historico", "historico", "Transações"],
            ["categorias", "categorias", "Categorias"],
            ["metas", "metas", "Metas financeiras"],
            ["relatorios", "relatorios", "Relatórios"]
          ].map(([id, icone, rotulo]) => (
            <button key={id} type="button"
              className={`viv-nav-item ${tela === "financeiro" && paginaFinanceira === id ? "viv-nav-item--active" : ""}`}
              title={rotulo} aria-label={rotulo}
              aria-current={tela === "financeiro" && paginaFinanceira === id ? "page" : undefined}
              onClick={() => { setTela("financeiro"); setPaginaFinanceira(id); }}>
              <MenuIcon name={icone} /><span className="viv-sidebar-label">{rotulo}</span>
            </button>
          ))}
          <button type="button" className={`viv-nav-item ${tela === "assinaturas" ? "viv-nav-item--active" : ""}`} title="Assinaturas" aria-label="Assinaturas" onClick={() => setTela("assinaturas")}>
            <MenuIcon name="admin" /><span className="viv-sidebar-label">Assinaturas</span>
          </button>
          {administrador && (
            <button type="button" className={`viv-nav-item ${tela === "admin" ? "viv-nav-item--active" : ""}`} title="Viv Admin" aria-label="Viv Admin" aria-current={tela === "admin" ? "page" : undefined} onClick={() => setTela("admin")}>
              <MenuIcon name="admin" /><span className="viv-sidebar-label">Viv Admin</span>
            </button>
          )}
        </nav>
        <div className="viv-sidebar-bottom">
          <button type="button" className={`viv-nav-item ${tela === "configuracoes" ? "viv-nav-item--active" : ""}`} title="Configurações" aria-label="Configurações" aria-current={tela === "configuracoes" ? "page" : undefined} onClick={() => setTela("configuracoes")}>
            <MenuIcon name="settings" /><span className="viv-sidebar-label">Configurações</span>
          </button>
          <button type="button" className="viv-nav-item viv-nav-exit" title="Sair" aria-label="Sair" onClick={sair}>
            <MenuIcon name="logout" /><span className="viv-sidebar-label">Sair</span>
          </button>
        </div>
      </aside>
      <main className="viv-shell-content" id="conteudo-principal">
        {tela === "configuracoes" ? (
          <Configuracoes usuario={usuario} />
        ) : tela === "assinaturas" ? (
          <Assinaturas />
        ) : tela === "admin" && administrador ? (
          <AdminPanel />
        ) : (
          <App pagina={paginaFinanceira} onPaginaChange={setPaginaFinanceira} />
        )}
      </main>
    </div>
  );
}

// ==========================================

// INICIALIZAÇÃO

// ==========================================

ReactDOM.createRoot(

  document.getElementById("root")

).render(

  <React.StrictMode>

    <Viv />

  </React.StrictMode>

);
